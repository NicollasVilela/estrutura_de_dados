package Exercicios01.exemplointerface1.dominio;

public interface Pagamento {
    void realizarPagamento(double valor);
}
