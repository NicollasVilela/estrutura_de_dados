package Exercicios01.exemplointerface2.dominio;

public interface FormaGeometrica {
    double calcularArea();
    double calcularPerimetro();
}
