package fase05.L05Exercicio08.dominio;

public interface Veiculo {
    void acelerar(int incremento);
    void frear(int decremento);
    int getVelocidadeAtual();
}
