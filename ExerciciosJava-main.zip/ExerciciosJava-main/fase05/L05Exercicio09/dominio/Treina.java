package fase05.L05Exercicio09.dominio;

public interface Treina {
    void ensinarTecnologia();
    void motivarEquipe();
}
