package fase05.L05Exercicio09.dominio;

public interface Desenvolve {
    void codar();
    void resolverProblemas();
}
