package fase05.L05Exercicio07.dominio;

public interface FiguraGeometrica {
    public String getNomeFigura();
    public int getArea();
    public int getPerimetro();
   }
